import os
import uuid
from django.db import models
from datetime import date
from django.core.validators import FileExtensionValidator
from django.contrib.auth.models import (AbstractBaseUser, AbstractUser, BaseUserManager,
                                        PermissionsMixin, Group)
# Create your models here.



def user_photo_file_path(instance, filename):
    """Generate file path for new recipe image"""
    ext = filename.split('.')[-1]
    filename = f'{uuid.uuid4()}.{ext}'

    return os.path.join('userphoto/', filename)


class UserManager(BaseUserManager):
    def create_user(self, email,phone_no, password=None, **extra_fields):
        """
        Creates and saves a User with the given email, date of
        birth and password.
        """
        if not email:
            raise ValueError('Users must have a email')
        user = self.model(
            email=email,
            phone_no=phone_no,
            **extra_fields
        )

        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self,email,phone_no, password):
        """
        Creates and saves a superuser with the given email, date of
        birth and password.
        """
        user = self.create_user(
            email,
            phone_no,
            password=password,
        )
        user.is_admin=True
        user.is_superuser = True
        user.is_staff = True
        user.is_active = True
        user.save(using=self._db)
        return user


class User(AbstractBaseUser):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4,unique=True, editable=False,blank=True)
    full_name = models.CharField(verbose_name='Full Name', max_length=100,blank=True,null=True)
    email = models.EmailField(unique=True,blank=True, null=True)
    phone_no = models.CharField(unique=True, max_length=30, null=True,error_messages={'required': 'Phone NO must be given'})
    user_photo = models.ImageField(upload_to=user_photo_file_path, null=True, blank=True)
    dob = models.DateField( null=True, blank=True, verbose_name='Date of Birth')
    age = models.IntegerField( null=True, blank=True, verbose_name='Age')
    country = models.CharField( max_length=255,null=True, blank=True)
    occupation = models.CharField( max_length=255,null=True, blank=True)
    full_address = models.TextField(null=True, blank=True)
    family_info = models.TextField(null=True, blank=True)
    family_photo = models.ImageField(upload_to=user_photo_file_path, null=True, blank=True)
    amount = models.FloatField(blank=True,null=True)
    text_message = models.TextField(null=True, blank=True)
    last_login  = models.DateTimeField(verbose_name='last login', auto_now=True)
    is_admin= models.BooleanField(default=False)
    is_active= models.BooleanField(default=False)
    is_staff = models.BooleanField(default=False)
    is_superuser = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = UserManager()
    USERNAME_FIELD = "email"
    REQUIRED_FIELDS = ["phone_no"]

    def __str__(self):
        if self.email or self.phone_no:
            return str(self.email)+ ' | ' +str(self.phone_no)
        
        else:
            return str(self.full_name)

    def has_perm(self, perm, obj=None):
        "Does the user have a specific permission?"
        # Simplest possible answer: Yes, always
        return True

    def has_module_perms(self, app_label):
        "Does the user have permissions to view the app `app_label`?"
        # Simplest possible answer: Yes, always
        return True

    def get_full_name(self):
        return self.full_name

    def get_short_name(self):
        return self.full_name

    def calculate_age(self):
        today = date.today()

        try: 
            birthday = self.dob.replace(year=today.year)
        # raised when birth date is February 29 and the current year is not a leap year
        except ValueError:
            birthday = self.dob.replace(year=today.year, day=born.day-1)

        if birthday > today:
            return today.year - born.year - 1
        else:
            return today.year - born.year


class UserDoc(models.Model):
    
    img = models.ImageField(upload_to='images_uploaded',null=True,blank=True)
    video = models.FileField(upload_to='videos_uploaded',null=True,validators=[FileExtensionValidator(allowed_extensions=['MOV','avi','mp4','webm','mkv'])])
    date_uploaded = models.DateTimeField(auto_now=True)
    user = models.ForeignKey(User,on_delete= models.CASCADE,null=True,blank=True,)

    def __str__(self):
        return str(self.img)



class HomeVideoList(models.Model):
    
    video = models.FileField(upload_to='videos_uploaded',null=True,validators=[FileExtensionValidator(allowed_extensions=['MOV','avi','mp4','webm','mkv'])])
    date_uploaded = models.DateTimeField(auto_now=True)

    def __str__(self):
        return str(self.video)


class Kraken(models.Model):
    user = models.ForeignKey(User,on_delete= models.CASCADE,null=True,blank=True,)
    amount = models.FloatField(blank=True,null=True)
    unixtime = models.IntegerField(default=0,blank=True,null=True)