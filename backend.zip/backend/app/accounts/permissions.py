from rest_framework import permissions

class  IsGETAuthenticatedUser(permissions.BasePermission):     
   
    def has_permission(self, request, view):
        if  request.user.is_anonymous==False: 
            perm_list = request.user.user_permissions.all().values_list('codename', flat=True)
            if  request.user.is_superuser:
                return True
            
            elif  request.method in ('PUT','POST','DELETE','HEAD', 'OPTIONS'):
                return False
        if  request.user.is_anonymous==True:
               
                if request.method in ('PUT', 'PATCH','POST','DELETE','HEAD', 'OPTIONS'):
                    return False
                else:
                    return True
        else:
            return True
        return True