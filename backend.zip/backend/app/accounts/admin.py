from django.contrib import admin
from .models import User,UserDoc,HomeVideoList,Kraken
# Register your models here.
admin.site.register(User)
admin.site.register(UserDoc)
admin.site.register(HomeVideoList)
admin.site.register(Kraken)

