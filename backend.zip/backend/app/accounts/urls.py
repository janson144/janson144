from django.urls import path, re_path, include
from rest_framework import routers

from . import views

router = routers.DefaultRouter()
router.register("home-videos",views.HomeVideoViewSet)
router.register('kraken',views.KrakenList)

urlpatterns = [
    path("", include(router.urls)),
    path("login/", views.LoginAPI.as_view()),
    path("registration/", views.RegisterAPI.as_view()),
    path("user-message/",views.UserMessageAPI.as_view()),
    path('user-profile/',views.UserProfileAPI.as_view()),
    # path('kraken/',views.KrakenList.as_view())


]