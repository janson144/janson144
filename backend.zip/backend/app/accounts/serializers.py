from rest_framework import serializers
from knox.models import AuthToken
from django.contrib.auth import get_user_model,authenticate
from django.contrib.auth.models import Group,ContentType
from django.contrib.auth.models import Permission
from django.contrib.auth.password_validation import validate_password

from .models import User,UserDoc,HomeVideoList,Kraken
User = get_user_model()

class LoginUserSerializer(serializers.Serializer):
    email=serializers.EmailField()
    phone_no = serializers.CharField()
    password = serializers.CharField()

    def validate(self, data):
        try:
            user = authenticate(**data)
            if user and user.is_active:
                return user
            else:
                raise serializers.ValidationError(
                "Sorry !! User  Inactive.Please contact to admin")
        except:
            raise serializers.ValidationError(
                "Wrong Username or Password")


# User Serializer
class UserSerializer(serializers.ModelSerializer):
    
    class Meta:
        model = User
        fields = ('id', 'phone_no', 'user_photo','email','full_address', 'is_active')



# Register Serializer
class RegisterSerializer(serializers.ModelSerializer):
    
    class Meta:
        model = User
        fields = ('id','email', 'phone_no','full_name','country','is_active')



# User Message Serializer
class UserMessageSerializer(serializers.ModelSerializer):
    
    class Meta:
        model = User
        fields = ('id','email', 'phone_no','full_name','country','text_message','user_photo','is_active')



# User Profile Serializer
class UserProfileSerializer(serializers.ModelSerializer):
    
    class Meta:
        model = User
        fields = ('id','email', 'phone_no','full_name','dob','age','country','text_message','user_photo','occupation','family_info','full_address','family_photo','is_active')


class HomeVideoSerializer(serializers.ModelSerializer):
    class Meta:
        model = HomeVideoList
        fields='__all__'


class KrakenSerializer(serializers.ModelSerializer):
    class Meta:
        model = Kraken
        fields = ('user','amount',)