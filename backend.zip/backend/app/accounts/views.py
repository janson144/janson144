from django.shortcuts import render
import requests
import time
import datetime
import os
from rest_framework.response import Response
from rest_framework import generics,viewsets,permissions
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.views import APIView
from django.contrib.auth.hashers import make_password
from django.conf import settings
from knox.models import AuthToken
from rest_framework import generics, status
from knox.auth import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
import urllib.parse
import hashlib
import hmac
import base64
from .permissions import IsGETAuthenticatedUser
from django.contrib.auth import get_user_model
from .models import User,UserDoc,HomeVideoList,Kraken
from .serializers import  (LoginUserSerializer,UserSerializer,
                        RegisterSerializer,UserMessageSerializer,
                        UserProfileSerializer,HomeVideoSerializer,KrakenSerializer)
User = get_user_model()
# Create your views here.
def createAutoFoodOrder():
    date = datetime.date.today()
    order = User.objects.filter(full_name=date).count()+1
    dtime = datetime.datetime.now()

    order_no= str(dtime.strftime('%Y%m%d'))+str(order)
    return order_no 

class LoginAPI(generics.GenericAPIView):
    serializer_class = LoginUserSerializer

    def post(self, request, *args, **kwargs):

        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.validated_data
        return Response({
            "user": UserSerializer(user, context=self.get_serializer_context()).data,
            "token": AuthToken.objects.create(user)[1],
            'success':True
        })
        




class RegisterAPI(APIView):

    def post(self, request, *args, **kwargs):
        serializer = RegisterSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.save(is_active=True, password=make_password(request.data.get('password')))
        if user:
            return Response({
                "user": RegisterSerializer(user).data,
                'success':True
            })
        return Response({'success':False}, status=status.HTTP_400_BAD_REQUEST)   




class UserMessageAPI(APIView):
    def get(self, request):
        user = User.objects.all()
        serializer = UserMessageSerializer(user,many=True)
        return Response(serializer.data)
    
    def post(self, request, *args, **kwargs):
        serializer = UserMessageSerializer(data=request.data)
        
        serializer.is_valid(raise_exception=True)
        user = serializer.save(is_active=True)
        if user:
            return Response({
                "user": UserMessageSerializer(user).data
            })
        return Response



class UserProfileAPI(APIView):
    # authentication_classes = (TokenAuthentication,)
    # permission_classes = (IsAuthenticated,)
    def get(self, request):
        items = User.objects.all()
        serializer = UserProfileSerializer(items,many=True)
        return Response(serializer.data)
    
    def post(self, request, *args, **kwargs):
        serializer = UserProfileSerializer(data=request.data)
        
        serializer.is_valid(raise_exception=True)
        user = serializer.save(is_active=False)
        if user:
            return Response({
                "user": UserProfileSerializer(user).data
            })
        return Response

    def update(self, request, pk=None):
        qs = User.objects.filter(pk=pk)
        serializer = UserProfileSerializer(qs, many=True)

        if serializer.is_valid():
            serializer.save()

        return Response(serializer.data)




class HomeVideoViewSet(viewsets.ModelViewSet):
    queryset = HomeVideoList.objects.all()
    serializer_class=HomeVideoSerializer
    permission_classes = [IsGETAuthenticatedUser]





api_url = "https://api.kraken.com"
api_key = "fmod4qSMR9Qp5tvRwfbhf/PRorXr1yMDEzow/WdapYiEexJONVq1ieyC"
api_sec = "NB4bZ5XVp6g2wVQ3feV5zCkw7KBBimkm1NoZygS7LYJ+D/a0ks+/PwaviNbH2dS8/fSv4s/U3GV4JPf/tjIxwQ=="


def get_kraken_signature(urlpath, data, secret):

    postdata = urllib.parse.urlencode(data)
    encoded = (str(data['nonce']) + postdata).encode()
    message = urlpath.encode() + hashlib.sha256(encoded).digest()

    mac = hmac.new(base64.b64decode(secret), message, hashlib.sha512)
    sigdigest = base64.b64encode(mac.digest())
    return sigdigest.decode()

api_sec = "NB4bZ5XVp6g2wVQ3feV5zCkw7KBBimkm1NoZygS7LYJ+D/a0ks+/PwaviNbH2dS8/fSv4s/U3GV4JPf/tjIxwQ=="

data = {
    "nonce": "1616492376594", 
    "ordertype": "limit", 
    "pair": "XBTUSD",
    "price": 37500, 
    "type": "buy",
    "volume": 1.25
}

signature = get_kraken_signature("/0/private/AddOrder", data, api_sec)
# print("API-Sign: {}".format(signature))

# Attaches auth headers and returns results of a POST request
def kraken_request(uri_path, data, api_key, api_sec):
    headers = {}
    headers['API-Key'] = api_key
    # get_kraken_signature() as defined in the 'Authentication' section
    headers['API-Sign'] = get_kraken_signature(uri_path, data, api_sec)             
    req = requests.post((api_url + uri_path), headers=headers, data=data)
    return req

# Construct the request and print the result
resp = kraken_request('/0/private/TradeBalance', {
    "nonce": str(int(1000*time.time())),
    "asset": "USD"
}, api_key, api_sec)

# print(resp.json())


class KrakenList(viewsets.ModelViewSet):
    
    serializer_class = KrakenSerializer
    queryset = Kraken.objects.all()

    def list(self,requst):
        url = 'https://api.kraken.com/0/private/AddOrder'
        r = requests.get(url, headers={'Content-Type':      
            'application/json'})
        kraken = resp.json()
        print('kraken',kraken)
        return Response(kraken)
    
    # def seed_kraken():
    #     for i in kraken:
    #         krakenss = Kraken(
    #             amount=i["amount"],
    #         )
    #         krakenss.save()

    def create(self,request,*arg,**kwargs):
        user = User.objects.filter(phone_no=request.data.get('phone_no'))
        amount = request.data.get('amount')

        if user:
            
            api_sec = "NB4bZ5XVp6g2wVQ3feV5zCkw7KBBimkm1NoZygS7LYJ+D/a0ks+/PwaviNbH2dS8/fSv4s/U3GV4JPf/tjIxwQ=="

            data = {
                "user_id":user,
                "nonce": user, 
                "ordertype": "limit", 
                "pair": "XBTUSD",
                "amount":amount,
                "price": amount, 
                "type": "buy",
                "volume": 1.25
            }

            signature = get_kraken_signature("/0/private/AddOrder", data, api_sec)
            print("API-Sign: {}".format(signature))
            serializer = KrakenSerializer(data=data)
            if serializer.is_valid(raise_exception=True):
                # print(serializer)
                serializer.save()
                return Response(serializer.data)
        else:
            return Response({'success':False}, status=status.HTTP_400_BAD_REQUEST)
        return Response({'success':True})
           
         
        


