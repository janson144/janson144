export const environment = {
  setTimeoutEnabled: false, // set true when creating a build
  rootURL: 'http://192.168.31.219:8000',
  loginURL: '/accounts/login/',
  signUpURL: '/accounts/registration/',
  userProfileUrl: '/accounts/user-profile/',
  videoUrl: '/accounts/home-videos/',
  messageUrl: '/accounts/user-message/',
  krakenUrl:'/accounts/kraken/',
 
};
