import * as React from "react";
import { useTheme } from "@mui/material/styles";
import Box from "@mui/material/Box";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import CardMedia from "@mui/material/CardMedia";
import IconButton from "@mui/material/IconButton";
import Typography from "@mui/material/Typography";
import SkipPreviousIcon from "@mui/icons-material/SkipPrevious";
import PlayArrowIcon from "@mui/icons-material/PlayArrow";
import SkipNextIcon from "@mui/icons-material/SkipNext";
import { environment } from "../consetent/environment-dev";

import Image from "next/image";

import user from "./../public/assets/images/user.png";

export default function AdminProfile() {
  const theme = useTheme();
  const [userInfo, setUserInfo] = React.useState<any[]>([]);
  const [token, setToken] = React.useState("");

  React.useEffect(() => {
    let token = localStorage.getItem("token");
    // setToken(token);
    fetch(`${environment.rootURL}${environment.userProfileUrl}`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        // Authorization: `Token ${token}`,
      },
    })
      .then((response) => response.json())
      .then((responseJson) => {
        setUserInfo(responseJson);
        // alert(JSON.stringify(responseJson));
      })
      .catch((error) => {
        alert(JSON.stringify(error));
      });
  }, []);

  return (
    <div style={{ width: "100vw", height: "100vw", backgroundColor: "#FFF" }}>
      <div style={{ paddingInline: "15vw" }}>
        {/* {token ? ( */}

        {userInfo.length > 0 ? (
          <>
            {userInfo.map((item, i) => (
              <Card
                key={i}
                sx={{ display: "flex", marginTop: 3 }}
                style={{ margin: 5, padding: 5 }}
              >
                <Typography
                  component="div"
                  variant="h5"
                  style={{ paddingInline: 5, color: "red" }}
                >
                  {i + 1}
                </Typography>

                {item.family_photo !== null ? (
                  <img
                    style={{
                      height: "10vw",
                      width: "10vw",
                      alignSelf: "center",
                      borderRadius: 10,
                      boxShadow: "0px 10px 10px tomato",
                    }}
                    src={
                      "http://192.168.31.219:8000/media/userphoto/8debff23-4bdd-40cc-9cef-afce842c6caa.png"
                    }
                  />
                ) : (
                  <Image
                    alt="Not Found"
                    src={user}
                    style={{
                      height: "10vw",
                      width: "10vw",
                      alignSelf: "center",
                      borderRadius: 10,
                      boxShadow: "0px 10px 10px tomato",
                    }}
                  />
                )}

                <Box
                  sx={{ display: "flex", flexDirection: "column" }}
                  style={{ margin: 20, padding: 20 }}
                >
                  <Typography
                    variant="body2"
                    color="text.secondary"
                    style={{
                      fontFamily: "Helvetica Neue",
                      fontWeight: 500,
                      fontSize: 16,
                    }}
                  >
                    {item.family_info}
                  </Typography>
                </Box>
              </Card>
            ))}
          </>
        ) : (
          <Typography
            variant="body2"
            color="text.secondary"
            style={{
              fontFamily: "Helvetica Neue",
              fontWeight: 500,
              fontSize: 16,
            }}
          >
            Admin not found
          </Typography>
        )}
      </div>
    </div>
  );
}
