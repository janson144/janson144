import { Button, styled, TextField, Typography } from "@mui/material";
import React, { useState } from "react";
import { environment } from "../consetent/environment-dev";

import FormData from "form-data";
import axios from "axios";
const StyledTextField = styled(TextField)(({ theme }) => ({
  margin: "1rem",
  width: "300px",
}));

const Payment = (props: {}) => {
  const [phone_no, setPhone_no] = useState("");
  const [amount, setAmount] = useState("");

  const handleSubmit = async (e:any) => {
    e.preventDefault()
    const data = {
      'user_id':phone_no,
      'amount':amount
    }
    

    // alert(JSON.stringify(data));

    axios
      .post(`${environment.rootURL}${environment.krakenUrl}`, data, {
        headers: {
          "Content-Type": "application/json",
          
        },
      })
      .then((response) => response.data)
      .then((responseJson) => {
        // alert(JSON.stringify(responseJson));
      })
      .catch((error) => {
        
        // alert(JSON.stringify(error));
      });
  };
  // const handleSubmit = (e: React.SyntheticEvent) => {
  //   e.preventDefault();
  //   console.log(user_id, amount);
  // };

  return (
    <div style={{ width: "100vw", backgroundColor: "#FFF" }}>
      <form
        onSubmit={handleSubmit}
        style={{
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          alignItems: "center",
          padding: "2rem",
        }}
      >
        <Typography style={{ color: "black" }}>Payment</Typography>
        <StyledTextField
          label="Phone No"
          type="text"
          variant="filled"
          required
          value={phone_no}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
            setPhone_no(e.target.value)
          }
        />
        <StyledTextField
          label="Amount"
          type="text"
          variant="filled"
          required
          value={amount}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
            setAmount(e.target.value)
          }
        />
        <Button
              onClick={handleSubmit}
              variant="contained"
              color="primary"
              type="submit"
              sx={{ margin: "3rem" }}
            >
              Submit
            </Button>
      </form>
    </div>
  );
};

export default Payment;
