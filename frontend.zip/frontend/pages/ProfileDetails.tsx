import React, { useState } from "react";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import CardMedia from "@mui/material/CardMedia";
import { Button, styled, TextField, Typography } from "@mui/material";
import Image from "next/image";
import { InferGetStaticPropsType } from "next";
import { environment } from "../consetent/environment-dev";
import FormData from "form-data";
import axios from "axios";

import user from "./../public/assets/images/user.png";

const StyledTextField = styled(TextField)(({ theme }) => ({
  margin: "1rem",
  width: "300px",
}));
type Data = {
  message: string;
  result: {
    id: string;
    name: string;
    age: string;
    occupation: string;
    contryName: string;
    family_info: string;
    fullAddrress: string;
    image: any;
  };
};
interface HTMLInputEvent extends Event {
  target: HTMLInputElement & EventTarget;
}

export default function ProfileDetails() {
  const [name, setName] = useState("");
  const [age, setAge] = useState("");
  const [occupation, setOccupation] = useState("");
  const [contryName, setContryName] = useState("");
  const [fullAddrress, setFullAddrress] = useState("");
  const [familyInfo, setFamilyInfo] = useState("");
  const [userInfo, setUserInfo] = useState({});

  const [image, setImage] = useState<File | null>(null);
  const [createObjectURL, setCreateObjectURL] = useState("");

  React.useEffect(() => {
    let token = localStorage.getItem("token");
  }, []);

  const handleSubmit = (e: React.SyntheticEvent) => {
    e.preventDefault();
  };

  const uploadToClient = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files[0]) {
      const i = event.target.files[0];
      setImage(i);
      setCreateObjectURL(URL.createObjectURL(i));
    }
  };

  const uploadToServer = async () => {
    let token = localStorage.getItem("token");
    const data = new FormData();
    data.append("family_photo", image);
    data.append("full_name", name);
    data.append("age", age);
    data.append("country", contryName);
    data.append("occupation", occupation);
    data.append("full_addrress", fullAddrress);
    data.append("family_info", familyInfo);

    // alert(JSON.stringify(data));

    axios
      .post(`${environment.rootURL}${environment.userProfileUrl}`, data, {
        headers: {
          "Content-Type": "multipart/form-data",
          Authorization: `Token ${token}`,
        },
      })
      .then((response) => response.data)
      .then((responseJson) => {
        alert(JSON.stringify(responseJson));
      })
      .catch((error) => {
        alert(JSON.stringify(error));
      });
  };

  return (
    <div
      style={{
        display: "flex",
        width: "100vw",
        justifyContent: "center",
        backgroundColor: "white",
      }}
    >
      <Card sx={{ maxWidth: 500 }}>
        <CardContent>
          <form
            onSubmit={handleSubmit}
            style={{
              display: "flex",
              flexDirection: "column",
              justifyContent: "center",
              alignItems: "center",
              padding: "2rem",
            }}
          >
            <StyledTextField
              label="Name"
              type="text"
              variant="filled"
              required
              value={name}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                setName(e.target.value)
              }
            />
            <StyledTextField
              label="Age"
              type=""
              variant="filled"
              required
              value={age}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                setAge(e.target.value)
              }
            />
            <StyledTextField
              label="Occupation"
              type=""
              variant="filled"
              required
              value={occupation}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                setOccupation(e.target.value)
              }
            />
            <StyledTextField
              label="Contry Name"
              type=""
              variant="filled"
              required
              value={contryName}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                setContryName(e.target.value)
              }
            />
            <StyledTextField
              label="Full Addrress"
              type=""
              variant="filled"
              required
              value={fullAddrress}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                setFullAddrress(e.target.value)
              }
            />
            <StyledTextField
              label="Family Information"
              type=""
              variant="filled"
              required
              value={familyInfo}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                setFamilyInfo(e.target.value)
              }
            />

            <div>
              {/* <img src={createObjectURL} /> */}
              <h5>Family Photo</h5>
              <input type="file" name="myImage" onChange={uploadToClient} />
            </div>

            <Button
              onClick={uploadToServer}
              variant="contained"
              color="primary"
              type="submit"
              sx={{ margin: "3rem" }}
            >
              Submit
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
