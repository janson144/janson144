import * as React from "react";
import { useTheme } from "@mui/material/styles";
import Box from "@mui/material/Box";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import CardMedia from "@mui/material/CardMedia";
import IconButton from "@mui/material/IconButton";
import Typography from "@mui/material/Typography";
import SkipPreviousIcon from "@mui/icons-material/SkipPrevious";
import PlayArrowIcon from "@mui/icons-material/PlayArrow";
import SkipNextIcon from "@mui/icons-material/SkipNext";
import ReactPlayer from "react-player";
import Image from "next/image";

import user from "./../public/assets/images/user2.png";

export default function CompliteTask() {
  const theme = useTheme();

  return (
    <div style={{ width: "100vw" }}>
      <div style={{ paddingInline: "15vw" }}>
        <Card sx={{ display: "flex", marginTop: 3 }} style={{margin:5, padding: 5 }}>
          <Typography
            component="div"
            variant="h5"
            style={{ paddingInline: 5, color: "red" }}
          >
            03
          </Typography>
          <Image
            alt="Not Found"
            src={user}
            style={{
              height: "10vw",
              width: "10vw",
              alignSelf:"center",
              borderRadius:10,
              // boxShadow:'0px 10px 10px tomato'
            }}
          />
          <Box sx={{ display: "flex", flexDirection: "column" }} style={{ margin:20,padding:20 }}>
            <Typography variant="body2" color="text.secondary" style={{ fontFamily: 'Helvetica Neue', fontWeight: 500, fontSize:22}}>
              This impressive paella is a perfect party dish and a fun meal to
              cook together with your guests. Add 1 cup of frozen peas along
              with the mussels, if you like. This impressive paella is a perfect
              party dish and a fun meal to cook together with your guests. Add 1
              cup of frozen peas along with the mussels, if you like. This
              impressive paella is a perfect party dish and a fun meal to cook
              together with your guests. Add 1 cup of frozen peas along with the
              mussels, if you like. This impressive paella is a perfect party
              dish and a fun meal to cook together with your guests. Add 1 cup
              of frozen peas along with the mussels, if you like. This
            </Typography>
          </Box>

          <ReactPlayer
            url="https://www.youtube.com/watch?v=wWgIAphfn2U"
            width="200%"
            height="300%"
            style={{
              alignSelf:"center",
            }}
          />
        </Card>
        <Card sx={{ display: "flex", marginTop: 3 }} style={{margin:5, padding: 5 }}>
          <Typography
            component="div"
            variant="h5"
            style={{ paddingInline: 5, color: "red" }}
          >
            03
          </Typography>
          <Image
            alt="Not Found"
            src={user}
            style={{
              height: "10vw",
              width: "10vw",
              alignSelf:"center",
              borderRadius:10,
              // boxShadow:'0px 10px 10px tomato'
            }}
          />
          <Box sx={{display: "flex", flexDirection: "column" }} style={{ margin:20,padding:20 }}>
            <Typography variant="body2" color="text.secondary" style={{ fontFamily: 'Helvetica Neue', fontWeight: 500, fontSize:22}}>
              This impressive paella is a perfect party dish and a fun meal to
              cook together with your guests. Add 1 cup of frozen peas along
              with the mussels, if you like. This impressive paella is a perfect
              party dish and a fun meal to cook together with your guests. Add 1
              cup of frozen peas along with the mussels, if you like. This
              impressive paella is a perfect party dish and a fun meal to cook
              together with your guests. Add 1 cup of frozen peas along with the
              mussels, if you like. This impressive paella is a perfect party
              dish and a fun meal to cook together with your guests. Add 1 cup
              of frozen peas along with the mussels, if you like. This
            </Typography>
          </Box>

          <ReactPlayer
            url="https://www.youtube.com/watch?v=wWgIAphfn2U"
            width="200%"
            height="300%"
            style={{
              alignSelf:"center",
            }}
          />
        </Card>
        <Card sx={{ display: "flex", marginTop: 3 }} style={{margin:5, padding: 5 }}>
          <Typography
            component="div"
            variant="h5"
            style={{ paddingInline: 5, color: "red" }}
          >
            03
          </Typography>
          <Image
            alt="Not Found"
            src={user}
            style={{
              height: "10vw",
              width: "10vw",
              alignSelf:"center",
              borderRadius:10,
              // boxShadow:'0px 10px 10px tomato'
            }}
          />
          <Box sx={{display: "flex", flexDirection: "column" }} style={{ margin:20,padding:20 }}>
            <Typography variant="body2" color="text.secondary" style={{ fontFamily: 'Helvetica Neue', fontWeight: 500, fontSize:22}}>
              This impressive paella is a perfect party dish and a fun meal to
              cook together with your guests. Add 1 cup of frozen peas along
              with the mussels, if you like. This impressive paella is a perfect
              party dish and a fun meal to cook together with your guests. Add 1
              cup of frozen peas along with the mussels, if you like. This
              impressive paella is a perfect party dish and a fun meal to cook
              together with your guests. Add 1 cup of frozen peas along with the
              mussels, if you like. This impressive paella is a perfect party
              dish and a fun meal to cook together with your guests. Add 1 cup
              of frozen peas along with the mussels, if you like. This
            </Typography>
          </Box>

          <ReactPlayer
            url="https://www.youtube.com/watch?v=wWgIAphfn2U"
            width="200%"
            height="300%"
            style={{
              alignSelf:"center",
            }}
          />
        </Card>
      </div>
    </div>
  );
}
