import React, { useState, useRef } from "react";
import { useRouter } from "next/router";
import Head from "next/head";
import Image from "next/image";
import { Inter } from "@next/font/google";
import styles from "../styles/Test.module.css";
import bg from "./../public/assets/images/bg.png";
import logo from "./../public/assets/images/logo.png";
import ArrowBackIos from "@mui/icons-material/ArrowBackIos";
import ArrowForwardIos from "@mui/icons-material/ArrowForwardIos";

import {
  LoginModalDialog,
  RegistrationModalDialog,
  SubmitMassageDialog,
} from "../component/ModalDialog";

import VideoPlayer from "../component/Video";
import Styled from "../component/styles";

const videoArray = [
  {
    url: "https://www.youtube.com/watch?v=4nAMqUut19k&ab_channel=radiovideo",
  },

  {
    url: "https://www.youtube.com/watch?v=4nAMqUut19k&ab_channel=radiovideo",
  },

  {
    url: "https://www.youtube.com/watch?v=4nAMqUut19k&ab_channel=radiovideo",
  },

  {
    url: "https://www.youtube.com/watch?v=4nAMqUut19k&ab_channel=radiovideo",
  },
  {
    url: "https://www.youtube.com/watch?v=4nAMqUut19k&ab_channel=radiovideo",
  },
  {
    url: "https://www.youtube.com/watch?v=4nAMqUut19k&ab_channel=radiovideo",
  },
  {
    url: "https://www.youtube.com/watch?v=4nAMqUut19k&ab_channel=radiovideo",
  },
  {
    url: "https://www.youtube.com/watch?v=4nAMqUut19k&ab_channel=radiovideo",
  },
  {
    url: "https://www.youtube.com/watch?v=4nAMqUut19k&ab_channel=radiovideo",
  },
  {
    url: "https://www.youtube.com/watch?v=4nAMqUut19k&ab_channel=radiovideo",
  },
];

const inter = Inter({ subsets: ["latin"] });

const sideScroll = (
  element: any,
  speed: number,
  distance: number,
  step: number
) => {
  let scrollAmount = 0;
  const slideTimer = setInterval(() => {
    element.scrollLeft += step;
    scrollAmount += Math.abs(step);
    if (scrollAmount >= distance) {
      clearInterval(slideTimer);
    }
  }, speed);
};

export default function Home() {
  const [openLogin, setOpenLogin] = useState(false);
  const [openReg, setOpenReg] = useState(false);
  const [openMessage, setOpenMessage] = useState(false);

  const contentWrapper = useRef(null);

  let router = useRouter();

  const handleOpenLogin = () => {
    setOpenLogin(true);
  };
  const handleOpenReg = () => {
    setOpenReg(true);
  };
  const handleOpenMessage = () => {
    setOpenMessage(true);
  };
  const handleClose = () => {
    setOpenLogin(false);
    setOpenReg(false);
    setOpenMessage(false);
  };

  return (
    <div className={styles.relative}>
      <div>
        <Image src={bg} alt="13" fill />

        <Image
          alt="Not Found"
          src={logo}
          style={{
            height: "7vw",
            width: "20vw",
            position: "absolute",
            left: 3,
            top: 3,
          }}
        />

        <div style={{ alignItems: "center" }}>
          <div
            // variant="contained"
            onClick={() => {
              router.push("/ProfileDetails");
            }}
            style={{
              position: "absolute",
              left: "40vw",
              top: "5vw",
              height: "12vw",
              width: "20vw",
              borderRadius: 70,
              cursor: "pointer",
              // backgroundColor: "green",
            }}
          />
          <div
            // variant="contained"
            onClick={() => {
              router.push("/adminProfile");
            }}
            style={{
              position: "absolute",
              left: "47.7vw",
              top: "11.5vw",
              height: "6vw",
              width: "4vw",
              borderRadius: 70,
              cursor: "pointer",
              // backgroundColor:'red'
            }}
          />
          <div
            // variant="contained"
            onClick={handleOpenReg}
            style={{
              position: "absolute",
              left: "40vw",
              top: "19.5vw",
              borderWidth: 1,
              height: "4vw",
              width: "6vw",
              borderRadius: 50,
              cursor: "pointer",
            }}
          />
          <RegistrationModalDialog open={openReg} handleClose={handleClose} />
          <div
            // variant="contained"
            onClick={handleOpenLogin}
            style={{
              position: "absolute",
              right: "40vw",
              top: "19.5vw",
              height: "4vw",
              width: "6vw",
              borderRadius: 50,
              cursor: "pointer",
            }}
          />
          <LoginModalDialog open={openLogin} handleClose={handleClose} />
          <div
            // variant="contained"
            onClick={handleOpenMessage}
            style={{
              position: "absolute",
              right: "48vw",
              top: "22.5vw",
              height: "6vw",
              width: "3vw",
              borderRadius: 50,
              cursor: "pointer",
            }}
          />

          <SubmitMassageDialog open={openMessage} handleClose={handleClose} />

          <div
            // variant="contained"
            onClick={() => {
              router.push("/completeTask");
            }}
            style={{
              position: "absolute",
              right: "48vw",
              top: "34vw",
              height: "7vw",
              width: "4vw",
              borderRadius: 50,
              cursor: "pointer",
            }}
          />
          <div
            onClick={() => {
              router.push("/Payment");
            }}
            style={{
              position: "absolute",
              right: "48vw",
              top: "43vw",
              height: "4vw",
              width: "6vw",
              borderRadius: 50,
              cursor: "pointer",
            }}
          />
        </div>
      </div>
      <div className={styles.video_layer}>
        <Styled.Container>
          <Styled.ButtonWrapper>
            <Styled.Button
              onClick={() => {
                sideScroll(contentWrapper.current, 25, 100, -10);
              }}
            >
              <ArrowBackIos />
            </Styled.Button>
            <Styled.ContentWrapper ref={contentWrapper}>
              {videoArray.map((url, i) => (
                <VideoPlayer
                  height="140px"
                  width="180px"
                  url={url.url}
                  key={i}
                />
              ))}
            </Styled.ContentWrapper>
            <Styled.Button
              onClick={() => {
                sideScroll(contentWrapper.current, 25, 100, 10);
              }}
            >
              <ArrowForwardIos />
            </Styled.Button>
          </Styled.ButtonWrapper>
        </Styled.Container>
      </div>
    </div>
  );
}
