/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
};

const withVideos = require("next-videos");

module.exports = withVideos({
  distDir: "../../.next",
});

module.exports = {
  modularizeImports: {
    "react-bootstrap": {
      transform: "react-bootstrap/lib/{{member}}",
    },
    lodash: {
      transform: "lodash/{{member}}",
    },
  },
};

module.exports = {
  async rewrites() {
    return [
      {
        source: "/api/:path*",
        destination: "https://api.example.com/:path*",
      },
    ];
  },
};

module.exports = nextConfig;
