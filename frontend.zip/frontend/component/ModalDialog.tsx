import { Dialog } from "@mui/material"
import LoginForm from "./LoginForm"
import RegistrationForm from "./RegistrationForm"
import SubmitMassage from "./SubmitMassage"

export const LoginModalDialog = (props: {open: boolean, handleClose: () => void}) => {
    return (
        <Dialog open={props.open} onClose={props.handleClose}>
            <LoginForm handleClose={props.handleClose}/>
        </Dialog>
        )
}

export const RegistrationModalDialog = (props: {open: boolean, handleClose: () => void}) => {

    return (
        <Dialog open={props.open} onClose={props.handleClose}>
            <RegistrationForm handleClose={props.handleClose}/>
        </Dialog>
        )
}
export const SubmitMassageDialog = (props: {open: boolean, handleClose: () => void}) => {

    return (
        <Dialog open={props.open} onClose={props.handleClose}>
            <SubmitMassage handleClose={props.handleClose}/>
        </Dialog>
        )
}

