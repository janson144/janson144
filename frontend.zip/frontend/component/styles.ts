import styled from "styled-components";

const Container = styled.div`

  overflow: hidden;
  width:100vw
  height:100px
  
`;

const Title = styled.h1`
  font-family: Arial, Helvetica, sans-serif;
  color: #fff;
  width: max-content;
`;

interface ContentProps {
  url: string;
}

const Content = styled.div<ContentProps>`
  width: 150px;
  height: 150px;
`;

const ContentWrapper = styled.div`
  display: flex;
  overflow: hidden;
  width: 90vw;
 
`;

const ButtonWrapper = styled.div`
  display: flex;
  width: 100%;
  margin-top: 20px;
  justify-content: space-between;
`;

const Button = styled.button`
  background: rgba(255,255,255,0.5);
  border: 0;
  color: #000000;
  padding: 5px 5px;
  border-radius: 8px;
  font-size: 15px;
  cursor: pointer;
  margin: 10px 10px,

  &:hover {
    opacity: 0.8;
  }
`;

export default {
  Container,
  Title,
  ContentWrapper,
  Content,
  ButtonWrapper,
  Button,
};
