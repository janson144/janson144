import { Button, styled, TextField, Typography } from "@mui/material";
import React, { useState } from "react";
import { environment } from "../consetent/environment-dev";

const StyledTextField = styled(TextField)(({ theme }) => ({
  margin: "1rem",
  width: "300px",
}));

const RegistrationForm = (props: { handleClose: () => void }) => {
  const [fullName, setFullName] = useState("");
  const [country, setCountry] = useState("");
  const [email, setEmail] = useState("");
  const [phone_number, setPhoneNumber] = useState("");
  const [password, setPassword] = useState("");

  const handleSubmit = async (e: React.SyntheticEvent) => {
    e.preventDefault();

    fetch(`${environment.rootURL}${environment.signUpURL}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        phone_no: phone_number,
        email: email,
        full_name: fullName,
        country: country,
        password: password,
      }),
    })
      .then((response) => response.json())
      .then((responseJson) => {
        alert(JSON.stringify(responseJson));
      })
      .catch((error) => {
        alert("error");
      });

    props.handleClose();
  };

  return (
    <form
      onSubmit={handleSubmit}
      style={{
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
        alignItems: "center",
        padding: "2rem",
      }}
    >
      <Typography>Registration</Typography>
      <StyledTextField
        label="Full Name"
        variant="filled"
        required
        value={fullName}
        onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
          setFullName(e.target.value)
        }
      />
      <StyledTextField
        label="Country"
        variant="filled"
        required
        value={country}
        onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
          setCountry(e.target.value)
        }
      />
      <StyledTextField
        label="Email"
        type="email"
        variant="filled"
        required
        value={email}
        onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
          setEmail(e.target.value)
        }
      />
      <StyledTextField
        label="Phone Number"
        type="text"
        variant="filled"
        required
        value={phone_number}
        onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
          setPhoneNumber(e.target.value)
        }
      />
      <StyledTextField
        label="Password"
        type="password"
        variant="filled"
        required
        value={password}
        onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
          setPassword(e.target.value)
        }
      />
      <div>
        <Button
          onClick={props.handleClose}
          variant="contained"
          sx={{ margin: "3rem" }}
        >
          Cancel
        </Button>
        <Button
          onClick={handleSubmit}
          variant="contained"
          color="primary"
          type="submit"
          sx={{ margin: "3rem" }}
        >
          Signup
        </Button>
      </div>
    </form>
  );
};

export default RegistrationForm;
