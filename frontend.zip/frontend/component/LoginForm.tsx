import { Button, styled, TextField, Typography } from "@mui/material";
import React, { useState } from "react";
import { environment } from "../consetent/environment-dev";
import useLocalStorage from "react-use-localstorage";

const StyledTextField = styled(TextField)(({ theme }) => ({
  margin: "1rem",
  width: "300px",
}));

const LoginForm = (props: { handleClose: () => void }) => {
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");

  const handleSubmit = (e: React.SyntheticEvent) => {
    e.preventDefault();
    fetch(`${environment.rootURL}${environment.loginURL}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        phone_no: phone,
        email: email,
        password: password,
      }),
    })
      .then((response) => response.json())
      .then((responseJson) => {
        if (responseJson.token) {
          localStorage.setItem("token", responseJson.token);
        }
        alert(JSON.stringify(responseJson));
      })
      .catch((error) => {
        alert("error");
      });
    props.handleClose();
  };

  return (
    <form
      onSubmit={handleSubmit}
      style={{
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
        alignItems: "center",
        padding: "2rem",
      }}
    >
      <Typography>Login</Typography>
      <StyledTextField
        label="Email"
        type="email"
        variant="filled"
        required
        value={email}
        onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
          setEmail(e.target.value)
        }
      />
      <StyledTextField
        label="Phone No"
        type="text"
        variant="filled"
        required
        value={phone}
        onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
          setPhone(e.target.value)
        }
      />
      <StyledTextField
        label="Password"
        type="password"
        variant="filled"
        required
        value={password}
        onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
          setPassword(e.target.value)
        }
      />
      <div>
        <Button
          onClick={props.handleClose}
          variant="contained"
          sx={{ margin: "3rem" }}
        >
          Cancel
        </Button>
        <Button
          onClick={handleSubmit}
          variant="contained"
          color="primary"
          type="submit"
          sx={{ margin: "3rem" }}
        >
          Login
        </Button>
      </div>
    </form>
  );
};

export default LoginForm;
