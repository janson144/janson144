import ReactPlayer from "react-player";
const VideoPlayer = (props: { url: string; height: string; width: string }) => {
  return (
    <div style={{ marginLeft: 5, border: 1, borderColor: "#FFF" }}>
      <ReactPlayer
        url={props.url}
        width={props.width ? props.width : "100%"}
        height={props.height?props.height:"80%"}
        controls={false}
        playing
        loop
        muted
      />
    </div>
  );
};

export default VideoPlayer;
